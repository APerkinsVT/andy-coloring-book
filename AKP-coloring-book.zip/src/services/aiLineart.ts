/* ============================================================================
   src/services/aiLineart.ts
   Purpose: Client-side service to request AI line art generation.
   - Accepts either a data URL (data:image/...) or an HTTP(S) URL.
   - Posts to /api/ai-lineart-via-url which normalizes & forwards to the core.
   - Returns the persisted line-art URL (Vercel Blob copy) and raw metadata.
   ============================================================================ */

/* =========================
   Section 1: Types & Config
   ========================= */

export type GenerateAiLineArtResponse = {
  /** Persisted URL to the AI line-art image (Vercel Blob). */
  imageUrl: string;
  /** Optional: raw payload from the Replicate poll result (for debugging). */
  raw?: any;
  /** Optional: original Replicate CDN URL if the server returns it. */
  sourceUrl?: string;
};

type PostBody =
  | { imageDataUrl: string; prompt?: string }
  | { imageUrl: string; prompt?: string };

const ROUTE = "/api/ai-lineart-via-url";

/** Flip to true to see verbose console logs from this module. */
const DEBUG = false;

/* ============================
   Section 2: Utility Functions
   ============================ */

/** Tiny type guard for strings. */
function isString(x: unknown): x is string {
  return typeof x === "string";
}

/** Returns true if s looks like a data URL. */
function isDataUrl(s: string): boolean {
  return s.startsWith("data:");
}

/** Returns true if s looks like http(s) URL. */
function isHttpUrl(s: string): boolean {
  return /^https?:\/\//i.test(s);
}

/** Print debug logs only when DEBUG is true. */
function dlog(...args: any[]) {
  if (DEBUG) console.log("[aiLineart]", ...args);
}

/** Best-effort readable snippet for unknown server responses. */
function preview(val: any, max = 280): string {
  try {
    const s = isString(val) ? val : JSON.stringify(val);
    return s.length > max ? s.slice(0, max) + "…" : s;
  } catch {
    return String(val);
  }
}

/* =========================================
   Section 3: Core call (exported API method)
   ========================================= */

/**
 * Generate AI line art.
 *
 * @param input - Either a data URL (data:image/...) or an HTTP(S) URL string.
 * @param prompt - Optional guidance text sent to the model (server may extend).
 * @returns { imageUrl, raw?, sourceUrl? }
 *
 * Usage:
 *   // If you have a Blob upload URL (recommended):
 *   await generateAiLineArt(originalBlobUrl);
 *
 *   // If you only have the base64 data URL:
 *   await generateAiLineArt(dataUrl);
 */
export async function generateAiLineArt(
  input: string,
  prompt?: string
): Promise<GenerateAiLineArtResponse> {
  /* Guard & normalize ------------------------------------------------------ */
  if (!isString(input) || input.length < 10) {
    throw new Error("generateAiLineArt: invalid input (expected a non-empty string)");
  }

  const payload: PostBody =
    isDataUrl(input)
      ? { imageDataUrl: input, prompt }
      : isHttpUrl(input)
      ? { imageUrl: input, prompt }
      : (() => {
          dlog("Unsupported input value:", preview(input));
          throw new Error(
            "generateAiLineArt: input must be a data URL (data:image/...) or HTTP(S) URL"
          );
        })();

  dlog("POST", ROUTE, { keys: Object.keys(payload) });

  /* POST to wrapper route -------------------------------------------------- */
  const resp = await fetch(ROUTE, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const text = await resp.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    // Non-JSON (shouldn’t happen; wrapper forces JSON). Surface readable info.
    const msg = `AI line art failed: ${resp.status} – non-JSON response: ${preview(text)}`;
    dlog(msg);
    throw new Error(msg);
  }

  /* Handle errors & shape -------------------------------------------------- */
  if (!resp.ok) {
    const detail = json?.detail || json?.error || preview(json);
    const msg = `AI line art failed: ${resp.status} – ${detail}`;
    dlog("Server error:", msg, "Raw:", json);
    throw new Error(msg);
  }

  // Expecting { imageUrl, raw?, sourceUrl? }
  const outUrl = json?.imageUrl;
  if (!isString(outUrl) || !isHttpUrl(outUrl)) {
    dlog("Malformed success payload; missing imageUrl:", json);
    throw new Error("AI line art succeeded but response had no valid imageUrl.");
  }

  dlog("Success imageUrl:", outUrl);
  return {
    imageUrl: outUrl,
    raw: json?.raw,
    sourceUrl: json?.sourceUrl,
  };
}

/* ==================================================
   Section 4: Optional helpers for callers (non-export)
   ================================================== */

/**
 * Example helper to defensively coerce a File into a data URL.
 * (Not used automatically; keep for reference or future needs.)
 */
async function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = () => reject(new Error("fileToDataUrl: FileReader error"));
    fr.onload = () => resolve(String(fr.result));
    fr.readAsDataURL(file);
  });
}

/* ==================================================
   Section 5: (Optional) default export shim
   ================================================== */

/**
 * Some codebases import this service as a default. If yours does not, this is harmless.
 * Keeping both named and default keeps swaps safer.
 */
export default generateAiLineArt;
