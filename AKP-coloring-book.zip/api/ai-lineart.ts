// api/ai-lineart.ts
// Node (serverless) function to convert a source image into printable line art via Replicate.
// Supports two config modes:
//
//   A) Model + Version (recommended)
//        REPLICATE_API_TOKEN=...              (required)
//        REPLICATE_MODEL=google/nano-banana   (example)
//        REPLICATE_VERSION=xxxxxxxx...        (the concrete version hash)
//
//   B) Deployment (back-compat)
//        REPLICATE_API_TOKEN=...              (required)
//        REPLICATE_DEPLOYMENT=owner/name
//
// Request JSON:
//   { imageDataUrl?: string, imageUrl?: string, prompt?: string }
//
// Response JSON:
//   { imageUrl: string, raw?: any }
//
// Notes:
// - This is a **Node** runtime function (no Edge flags).
// - If given imageDataUrl, we upload bytes to Vercel Blob and pass Replicate a URL.

import type { IncomingMessage, ServerResponse } from "http";
import { put } from "@vercel/blob";

type J = Record<string, any>;

function reply(res: ServerResponse, status: number, data: J) {
  res.statusCode = status;
  res.setHeader("content-type", "application/json");
  res.end(JSON.stringify(data));
}
function fail(res: ServerResponse, status: number, msg: string, extra?: J) {
  reply(res, status, { error: msg, ...(extra || {}) });
}

// -------- helpers ------------------------------------------------------------

async function readJson(req: IncomingMessage): Promise<J> {
  const chunks: Buffer[] = [];
  for await (const c of req) chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c));
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf-8"));
  } catch {
    return {};
  }
}

async function storeDataUrlToBlob(dataUrl: string): Promise<string> {
  const m = /^data:(.+?);base64,(.+)$/.exec(dataUrl);
  if (!m) throw new Error("Invalid data URL");

  const contentType = m[1] || "image/png";
  const bytes = Buffer.from(m[2], "base64");
  const ext =
    contentType.includes("jpeg") ? "jpg" :
    contentType.includes("png")  ? "png" :
    contentType.includes("webp") ? "webp" : "bin";

  const name = `original-${Date.now()}.${ext}`;
  const stored = await put(name, bytes, { access: "public", contentType });
  return stored.url; // public, cacheable URL for Replicate
}

async function runReplicate(srcUrl: string, userPrompt?: string): Promise<{ imageUrl: string; raw: any }> {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) throw new Error("Missing REPLICATE_API_TOKEN");

  const deployment = process.env.REPLICATE_DEPLOYMENT; // optional
  const model = process.env.REPLICATE_MODEL;
  const version = process.env.REPLICATE_VERSION;

  const prompt =
    (userPrompt ?? "").trim() ||
    "Convert the image into clean, high-contrast black-and-white line art suitable for printing and coloring. Preserve edges; avoid shading.";

  const base = "https://api.replicate.com/v1";
  const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

  let createUrl = `${base}/predictions`;
  let body: any;

  if (deployment) {
    // Legacy path: use a deployment; version not needed
    createUrl = `${base}/deployments/${deployment}/predictions`;
    body = { input: { image: srcUrl, prompt } };
  } else {
    if (!version) throw new Error("Missing REPLICATE_VERSION");
    // Standard predictions API with explicit version
    body = {
      version,
      ...(model ? { model } : {}),
      input: { image: srcUrl, prompt },
    };
  }

  const created = await fetch(createUrl, { method: "POST", headers, body: JSON.stringify(body) });
  const cj = await created.json().catch(() => ({}));
  if (!created.ok) {
    const preview = typeof cj === "object" ? JSON.stringify(cj) : await created.text();
    throw new Error(`Replicate create failed: ${created.status} ${preview}`);
  }

  const statusUrl: string | undefined = cj?.urls?.get || cj?.urls?.status || cj?.urls?.self;
  if (!statusUrl) throw new Error("Replicate returned no status URL");

  // Poll
  let pred = cj;
  const start = Date.now();
  const TIMEOUT = 90_000;

  while (true) {
    const s = pred?.status;
    if (s === "succeeded" || s === "failed" || s === "canceled") break;
    if (Date.now() - start > TIMEOUT) throw new Error("Replicate timed out");
    await new Promise(r => setTimeout(r, 1200));
    const r = await fetch(statusUrl, { headers });
    pred = await r.json().catch(() => ({}));
  }

  if (pred?.status !== "succeeded") {
    throw new Error(`Replicate finished with status "${pred?.status}" ${JSON.stringify(pred ?? {})}`);
  }

  // Output normalization: accept string, array, or object
  let outUrl: string | undefined;
  const out = pred?.output;

  if (typeof out === "string") {
    outUrl = out;
  } else if (Array.isArray(out)) {
    outUrl = out.find((v: any) => typeof v === "string" && /^https?:\/\//.test(v));
  } else if (out && typeof out === "object") {
    outUrl = out["image"] || out["url"] || out["images"]?.[0] || out["output"]?.[0];
  }

  if (!outUrl) throw new Error("Could not parse output image URL from Replicate response");
  return { imageUrl: outUrl, raw: pred };
}

// -------- handler ------------------------------------------------------------

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  try {
    if (req.method !== "POST") return fail(res, 405, "Method not allowed");

    const body = await readJson(req);
    const imageDataUrl: string | undefined = body?.imageDataUrl;
    const imageUrlIn: string | undefined = body?.imageUrl;
    const prompt: string | undefined = body?.prompt;

    if (!imageDataUrl && !imageUrlIn) return fail(res, 400, "Provide imageDataUrl or imageUrl");

    let srcUrl = imageUrlIn;
    if (!srcUrl && imageDataUrl) srcUrl = await storeDataUrlToBlob(imageDataUrl);
    if (!srcUrl) return fail(res, 400, "Could not derive source image URL");

    const { imageUrl, raw } = await runReplicate(srcUrl, prompt);
    return reply(res, 200, { imageUrl, raw });
  } catch (err: any) {
    return fail(res, 500, "ai-lineart crashed", { detail: err?.message || String(err) });
  }
}
