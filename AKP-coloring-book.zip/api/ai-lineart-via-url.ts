// api/ai-lineart-via-url.ts
// Normalizing wrapper:
//  - Accepts { imageDataUrl? | imageUrl?, prompt? } from the client.
//  - Validates presence of one of the image fields.
//  - Forwards the same shape to /api/ai-lineart (core).
//  - Always returns JSON (including errors).

export const config = { runtime: "nodejs" };

type Body = { imageDataUrl?: string; imageUrl?: string; prompt?: string };

export default async function handler(req: any, res: any) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    let body: Body = {};
    try {
      body = typeof req.body === "string" ? JSON.parse(req.body) : req.body || {};
    } catch (e: any) {
      return res.status(400).json({ error: "Invalid JSON body", detail: e?.message });
    }

    const { imageDataUrl, imageUrl, prompt } = body;
    if (!imageDataUrl && !imageUrl) {
      return res.status(400).json({ error: "Provide imageDataUrl or imageUrl" });
    }

    // Build origin for local/prod
    const proto = (req.headers["x-forwarded-proto"] as string) || "http";
    const host = (req.headers["x-forwarded-host"] as string) || req.headers.host || "localhost:3000";
    const origin = `${proto}://${host}`;

    // Forward to the core endpoint with the **same keys**
    const r = await fetch(`${origin}/api/ai-lineart`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ imageDataUrl, imageUrl, prompt }),
    });

    const ct = r.headers.get("content-type") || "";
    if (ct.includes("application/json")) {
      const json = await r.json().catch(() => null);
      if (json) return res.status(r.status).json(json);
    }

    // Non-JSON fallback (shouldn’t happen with the core, but be safe)
    const txt = await r.text().catch(() => "");
    return res.status(r.status).json({
      error: "ai-lineart core returned non-JSON",
      preview: txt.slice(0, 1000),
      status: r.status,
    });
  } catch (err: any) {
    return res.status(500).json({
      error: "ai-lineart-via-url crashed",
      detail: err?.message || String(err),
    });
  }
}
